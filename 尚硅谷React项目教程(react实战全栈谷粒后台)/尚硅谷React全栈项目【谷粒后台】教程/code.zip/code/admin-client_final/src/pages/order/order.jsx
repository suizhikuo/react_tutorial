import React from 'react'
import './order.less'

/*
Home路由组件
 */
export default function Order(props) {
  return (
    <div className="order">
      订单管理模块学生实战开发中...
    </div>
  )
}