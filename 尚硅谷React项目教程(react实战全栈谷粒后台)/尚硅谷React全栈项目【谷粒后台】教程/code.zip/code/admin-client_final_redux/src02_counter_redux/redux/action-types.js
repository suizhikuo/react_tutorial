/*
包含n个action type常量名称的模块
 */
export const INCREMENT = 'increment'
export const DECREMENT = 'decrement'