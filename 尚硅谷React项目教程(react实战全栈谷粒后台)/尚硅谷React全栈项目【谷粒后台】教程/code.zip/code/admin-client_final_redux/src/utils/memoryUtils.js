/*
用来在内存保存一些数据的工具模块
 */
export default {
  user: {}, // 保存当前登陆的user
  product: {}, // 指定的商品对象
}